// Game Over
// A first C++ program

#include <iostream>

int main()
{
	std::cout << "Game Over!" << std::endl;
	return 0;
}