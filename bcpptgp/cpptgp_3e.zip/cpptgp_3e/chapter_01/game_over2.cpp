// Game Over 2.0
// Demonstrates a using directive

#include <iostream>
using namespace std;

int main()
{
	cout << "Game Over!" << endl;
	return 0;
}

