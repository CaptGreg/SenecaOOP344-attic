// Game Over 3.0
// Demonstrates using declarations

#include <iostream>

using std::cout;	
using std::endl;

int main()
{
	cout << "Game Over!" << endl;
	return 0;
}

